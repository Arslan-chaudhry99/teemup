import axios from "axios";
const remoteMethod = async ({ type = "GET", data = [] || {}, url }) => {


  return type === "POST" ? axios.post(url, data) : axios.get();


};

export default remoteMethod;
