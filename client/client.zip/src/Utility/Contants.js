export const baseUrl = 'http://localhost:3001/';

export const routes = {
           login_route: `${baseUrl}auth/login`,
           signup_route: `${baseUrl}auth/register`
};